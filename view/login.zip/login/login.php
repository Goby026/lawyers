<style>
body{
    margin: 0;
}

video{
    position: fixed;
    min-width: 100%;
    min-height: 100%;
    
    top: 50%;
    left: 50%;
    
    transform: translateX(-50%) translateY(-50%);
    z-index: -1;
    
}

</style>
<video src="../assets/images/lima.mp4" autoplay loop >
</video>

